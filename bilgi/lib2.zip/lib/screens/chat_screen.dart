import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../services/des_service.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  late final String username;
  late final String password; // şimdilik tutuluyor (ileride DES key olabilir)

  bool _initialized = false;

  final TextEditingController _messageController = TextEditingController();

  // Kullanıcı listesi (sunucudan çekilecek) - username ve online durumu
  List<Map<String, dynamic>> _users = [];
  String? _selectedUser;

  // Mesajlar
  final List<_ChatMessage> _messages = [];

  // UI state
  bool _loading = false;
  String? _error;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    if (_initialized) return;

    final args =
        ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;

    username = (args?['username'] ?? 'unknown').toString();
    password = (args?['password'] ?? '').toString();

    _initialized = true;

    // İlk açılışta kullanıcıları ve mesajları çek
    _loadUsersAndMessages();
  }

  Future<void> _loadUsersAndMessages() async {
    await _loadUsers();
    if (_selectedUser != null) {
      await _loadMessages();
    }
  }

  Future<void> _loadUsers() async {
    try {
      final users = await ApiService.getUsers();

      // Kendi kullanıcı adımızı listeden çıkar
      final filteredUsers =
          users.where((u) => u['username'] != username).toList();

      setState(() {
        _users = filteredUsers;
        // İlk kullanıcıyı seç (eğer varsa)
        if (_selectedUser == null && _users.isNotEmpty) {
          _selectedUser = _users.first['username'];
        }
      });
    } catch (e) {
      setState(() => _error = 'Kullanıcılar yüklenemedi: $e');
    }
  }

  Future<void> _loadMessages() async {
    if (_selectedUser == null) return;

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final raw = await ApiService.fetchMessages(
        username: username,
        withUser: _selectedUser!,
      );

      // raw: List<Map<String,dynamic>>
      final msgs =
          raw.map((e) {
            final sender = (e['sender'] ?? '').toString();
            final receiver = (e['receiver'] ?? e['to'] ?? '').toString();
            final encryptedText = (e['message'] ?? e['text'] ?? '').toString();

            final tsStr =
                (e['ts'] ?? e['timestamp'] ?? e['time'] ?? '').toString();
            final ts =
                DateTime.tryParse(tsStr) ??
                DateTime.fromMillisecondsSinceEpoch(0);

            final isMe = sender == username;

            // ✅ PROTOKOL: Gelen mesajı kendi password'ümüzle deşifrele
            String decryptedText;
            try {
              decryptedText = DesService.decryptFromBase64(
                encryptedText,
                password,
              );
            } catch (e) {
              // Şifre çözme hatası olursa (eski mesajlar vs.)
              decryptedText =
                  '[Şifre çözülemedi: ${encryptedText.substring(0, encryptedText.length > 20 ? 20 : encryptedText.length)}...]';
            }

            return _ChatMessage(
              from: sender.isEmpty ? 'unknown' : sender,
              to: receiver.isEmpty ? _selectedUser! : receiver,
              text: decryptedText, // ✅ Deşifrelenmiş mesaj gösteriliyor
              isMe: isMe,
              time: ts,
            );
          }).toList();

      // ✅ zamana göre sırala
      msgs.sort((a, b) => a.time.compareTo(b.time));

      setState(() {
        _messages
          ..clear()
          ..addAll(msgs);
      });
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _sendMessageToServer(String text) async {
    if (_selectedUser == null) return;

    final nowIso = DateTime.now().toIso8601String();

    // ✅ PROTOKOL: Mesajı kendi password'ümüzle şifrele
    final encryptedMessage = DesService.encryptToBase64(text, password);

    final ok = await ApiService.sendMessage(
      sender: username,
      receiver: _selectedUser!,
      message: encryptedMessage, // ✅ Şifreli mesaj gönderiliyor
      ts: nowIso,
    );

    if (!ok) {
      throw Exception('Mesaj gönderilemedi.');
    }
  }

  void _sendMessage() async {
    final text = _messageController.text.trim();
    if (text.isEmpty) return;
    if (_selectedUser == null) return;

    // Optimistic UI: hemen ekrana ekle
    final localNow = DateTime.now();
    final localMsg = _ChatMessage(
      from: username,
      to: _selectedUser!,
      text: text,
      isMe: true,
      time: localNow,
    );

    setState(() {
      _error = null;
      _messages.add(localMsg);
    });

    _messageController.clear();

    try {
      await _sendMessageToServer(text);

      // Sunucudan tekrar çekelim (tek source of truth olsun)
      await _loadMessages();
    } catch (e) {
      setState(() => _error = e.toString());
    }
  }

  @override
  void dispose() {
    _messageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDesktopWide = MediaQuery.of(context).size.width >= 900;

    return Scaffold(
      appBar: AppBar(
        title: Text('Secure Chat — $username'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Çıkış Yap',
            onPressed: () {
              Navigator.pushReplacementNamed(context, '/welcome');
            },
          ),
        ],
      ),
      body:
          isDesktopWide
              ? Row(
                children: [
                  _buildUsersPanel(width: 260),
                  const VerticalDivider(width: 1),
                  Expanded(child: _buildChatPanel()),
                ],
              )
              : Column(
                children: [
                  _buildUsersPanel(height: 140),
                  const Divider(height: 1),
                  Expanded(child: _buildChatPanel()),
                ],
              ),
    );
  }

  Widget _buildUsersPanel({double? width, double? height}) {
    return SizedBox(
      width: width,
      height: height,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Padding(
            padding: EdgeInsets.all(12),
            child: Text(
              'Kullanıcılar',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ),
          Expanded(
            child: ListView.separated(
              itemCount: _users.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, i) {
                final userObj = _users[i];
                final username = userObj['username']?.toString() ?? '';
                final isOnline = userObj['online'] == true;
                final selected = username == _selectedUser;

                return ListTile(
                  leading: Container(
                    width: 10,
                    height: 10,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: isOnline ? Colors.green : Colors.grey,
                    ),
                  ),
                  title: Text(username),
                  selected: selected,
                  onTap: () async {
                    setState(() => _selectedUser = username);
                    await _loadMessages();
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChatPanel() {
    return Column(
      children: [
        // Üst başlık: kime yazıyoruz?
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          child: Text(
            _selectedUser == null
                ? 'Bir kullanıcı seç'
                : 'Sohbet: $_selectedUser',
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
        ),

        const Divider(height: 1),

        // Hata barı (varsa)
        if (_error != null)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Text(
              _error!,
              style: const TextStyle(color: Colors.redAccent),
              textAlign: TextAlign.center,
            ),
          ),

        // Mesaj listesi
        Expanded(
          child:
              _loading
                  ? const Center(child: CircularProgressIndicator())
                  : _messages.isEmpty
                  ? const Center(
                    child: Text(
                      'Henüz mesaj yok',
                      style: TextStyle(color: Colors.grey),
                    ),
                  )
                  : ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: _messages.length,
                    itemBuilder: (context, i) {
                      final m = _messages[i];
                      return _MessageBubble(message: m);
                    },
                  ),
        ),

        const Divider(height: 1),

        // Mesaj yazma alanı
        Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _messageController,
                  onSubmitted: (_) => _sendMessage(),
                  decoration: const InputDecoration(
                    hintText: 'Mesaj yaz...',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              ElevatedButton(
                onPressed: _sendMessage,
                child: const Text('Gönder'),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// --------------------
// Basit mesaj modeli
// --------------------
class _ChatMessage {
  final String from;
  final String to;
  final String text;
  final bool isMe;
  final DateTime time;

  _ChatMessage({
    required this.from,
    required this.to,
    required this.text,
    required this.isMe,
    required this.time,
  });
}

// --------------------
// Mesaj balonu widget’ı
// --------------------
class _MessageBubble extends StatelessWidget {
  final _ChatMessage message;

  const _MessageBubble({required this.message});

  @override
  Widget build(BuildContext context) {
    final align =
        message.isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start;

    final bg = message.isMe ? Colors.blueGrey.shade700 : Colors.grey.shade800;

    return Column(
      crossAxisAlignment: align,
      children: [
        Container(
          margin: const EdgeInsets.symmetric(vertical: 6),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          constraints: const BoxConstraints(maxWidth: 520),
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Text(message.text),
        ),
      ],
    );
  }
}
