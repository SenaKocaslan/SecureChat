import 'package:flutter/material.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Row(
        children: [
          // SOL: Görsel panel
          Expanded(
            flex: 3,
            child: Image.asset(
              'assets/images/welcome.png',
              fit: BoxFit.cover,
              width: double.infinity, // burada sorun yok çünkü Expanded içinde
              height: double.infinity,
            ),
          ),

          // SAĞ: Yazı + buton paneli
          Expanded(
            flex: 2,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 36.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch, // butonlar panel genişliğini doldursun
                children: [
                  const Text(
                    'Welcome to Secure Chat',
                    style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.left,
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Your privacy is our priority. Chat securely with end-to-end encryption.',
                    style: TextStyle(fontSize: 16, color: Colors.white70),
                  ),
                  const SizedBox(height: 28),

                  ElevatedButton(
                    onPressed: () => Navigator.pushNamed(context, '/login'),
                    child: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 12),
                      child: Text('Login'),
                    ),
                  ),
                  const SizedBox(height: 14),
                  OutlinedButton(
                    onPressed: () => Navigator.pushNamed(context, '/register'),
                    child: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 12),
                      child: Text('Sign Up'),
                    ),
                  ),
                  const SizedBox(height: 14),
                  TextButton(
                    onPressed: () => Navigator.pushNamed(context, '/chat'),
                    child: const Text('Skip (Test Chat)'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
