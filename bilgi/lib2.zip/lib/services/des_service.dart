import 'dart:convert';
import 'dart:typed_data';
import 'package:dart_des/dart_des.dart';

/// DES şifreleme servisi
/// 8-byte key ile DES ECB mode kullanır
class DesService {
  /// Password/Key string -> 8-byte DES key
  static Uint8List _derive8ByteKey(String password) {
    final bytes = utf8.encode(password);
    final key = Uint8List(8);
    for (int i = 0; i < 8; i++) {
      key[i] = (i < bytes.length) ? bytes[i] : 0x00;
    }
    return key;
  }

  /// Mesajı DES ile şifreler ve Base64 döndürür
  static String encryptToBase64(String plainText, String passwordKey) {
    final keyBytes = _derive8ByteKey(passwordKey);

    // DES ECB mode
    final des = DES(key: keyBytes, mode: DESMode.ECB);

    // Plaintext'i byte'a çevir
    final plainBytes = utf8.encode(plainText);

    // Şifrele
    final encryptedBytes = des.encrypt(plainBytes);

    // Base64'e çevir
    return base64Encode(encryptedBytes);
  }

  /// Base64 şifreli mesajı DES ile deşifreler
  static String decryptFromBase64(String base64CipherText, String passwordKey) {
    final keyBytes = _derive8ByteKey(passwordKey);

    // DES ECB mode
    final des = DES(key: keyBytes, mode: DESMode.ECB);

    // Base64'ten byte'a çevir
    final encryptedBytes = base64Decode(base64CipherText);

    // Deşifrele
    final decryptedBytes = des.decrypt(encryptedBytes);

    // UTF-8 string'e çevir
    return utf8.decode(decryptedBytes);
  }
}
