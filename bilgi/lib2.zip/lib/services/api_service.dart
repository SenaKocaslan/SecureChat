import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

class ApiService {
  static const bool kMockApi = false;

  static const String baseUrl = 'http://172.18.16.196:8000';

  static Future<bool> login(String username, String password) async {
    if (kMockApi) {
      await Future.delayed(const Duration(milliseconds: 300));
      return true;
    }

    final uri = Uri.parse('$baseUrl/login');

    final response = await http.post(
      uri,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'username': username, 'password': password}),
    );

    if (response.statusCode == 200) {
      return true;
    } else {
      print('Login error: ${response.statusCode} - ${response.body}');
      return false;
    }
  }

  static Future<bool> registerUser(String username, File stegoImage) async {
    if (kMockApi) {
      await Future.delayed(const Duration(milliseconds: 300));
      return true;
    }

    final uri = Uri.parse('$baseUrl/register');

    final request =
        http.MultipartRequest('POST', uri)
          ..fields['username'] = username
          ..files.add(
            await http.MultipartFile.fromPath('image', stegoImage.path),
          );

    final streamed = await request.send();
    final responseBody = await streamed.stream.bytesToString();

    if (streamed.statusCode == 200) {
      return true;
    } else {
      print('Register error: ${streamed.statusCode} - $responseBody');
      return false;
    }
  }

  /// Kullanıcı listesini online durumlarıyla birlikte getirir
  /// Dönen format: [{"username": "ali", "online": true}, ...]
  static Future<List<Map<String, dynamic>>> getUsers() async {
    if (kMockApi) {
      await Future.delayed(const Duration(milliseconds: 200));
      return [
        {'username': 'alice', 'online': true},
        {'username': 'bob', 'online': false},
        {'username': 'charlie', 'online': true},
      ];
    }

    final uri = Uri.parse('$baseUrl/users');
    final response = await http.get(uri);

    if (response.statusCode != 200) {
      print('Users error: ${response.statusCode} - ${response.body}');
      return [];
    }

    final data = jsonDecode(response.body);

    // Sunucu direkt liste dönüyorsa
    if (data is List) {
      return data.map<Map<String, dynamic>>((e) {
        if (e is Map) {
          return Map<String, dynamic>.from(e);
        }
        // Sadece string dönüyorsa, online durumunu false yap
        return {'username': e.toString(), 'online': false};
      }).toList();
    }

    // {"users": [...]} formatında dönüyorsa
    if (data is Map && data['users'] is List) {
      final usersList = data['users'] as List;
      return usersList.map<Map<String, dynamic>>((e) {
        if (e is Map) {
          return Map<String, dynamic>.from(e);
        }
        return {'username': e.toString(), 'online': false};
      }).toList();
    }

    return [];
  }

  // ---------------------------------------------------------------------------
  // CHAT
  // ---------------------------------------------------------------------------

  static Future<bool> sendMessage({
    required String sender,
    required String receiver,
    required String message,
    String? ts, // opsiyonel
  }) async {
    if (kMockApi) {
      await Future.delayed(const Duration(milliseconds: 150));
      return true;
    }

    final uri = Uri.parse('$baseUrl/send-message');

    final payload = <String, dynamic>{
      'sender': sender,
      'receiver': receiver,
      'message': message,
    };
    if (ts != null && ts.isNotEmpty) payload['ts'] = ts;

    final response = await http.post(
      uri,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(payload),
    );

    if (response.statusCode == 200) {
      return true;
    } else {
      print('SendMessage error: ${response.statusCode} - ${response.body}');
      return false;
    }
  }

  /// ✅ Artık List<Map<String,dynamic>> döndürüyor.
  /// ChatScreen tarafında e['sender'], e['message'], e['ts'] gibi okunabilir.
  static Future<List<Map<String, dynamic>>> fetchMessages({
    required String username,
    required String withUser,
  }) async {
    if (kMockApi) {
      await Future.delayed(const Duration(milliseconds: 200));
      return [
        {
          'sender': username,
          'receiver': withUser,
          'message': 'mock mesaj',
          'ts': DateTime.now().toIso8601String(),
        },
      ];
    }

    final uri = Uri.parse(
      '$baseUrl/messages',
    ).replace(queryParameters: {'username': username, 'with': withUser});

    final response = await http.get(uri);

    if (response.statusCode != 200) {
      throw Exception(
        'FetchMessages error: ${response.statusCode} - ${response.body}',
      );
    }

    final data = jsonDecode(response.body);

    // 1) Direkt liste dönüyorsa: [ {...}, {...} ]
    if (data is List) {
      return data
          .map<Map<String, dynamic>>((e) => Map<String, dynamic>.from(e))
          .toList();
    }

    // 2) {"messages":[...]} dönüyorsa
    if (data is Map && data['messages'] is List) {
      final list = data['messages'] as List;
      return list
          .map<Map<String, dynamic>>((e) => Map<String, dynamic>.from(e))
          .toList();
    }

    throw Exception('Unexpected messages format: ${response.body}');
  }
}
