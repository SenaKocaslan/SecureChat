import 'dart:convert';
import 'dart:typed_data';
import 'package:image/image.dart' as img;

class StegoService {
  /// LSB steganografi ile secret metni resme gömer
  /// Çıkış: PNG (lossless)
  static Uint8List embedText(Uint8List imageBytes, String secret) {
    // 1) Resmi decode et
    final image = img.decodeImage(imageBytes);
    if (image == null) {
      throw Exception('Resim decode edilemedi');
    }

    // 2) Secret → UTF-8 bytes
    final secretBytes = utf8.encode(secret);
    final length = secretBytes.length;

    // 3) Payload = [4 byte length] + secret
    final payload = Uint8List(4 + length);
    payload[0] = (length >> 24) & 0xFF;
    payload[1] = (length >> 16) & 0xFF;
    payload[2] = (length >> 8) & 0xFF;
    payload[3] = length & 0xFF;
    payload.setAll(4, secretBytes);

    // 4) Kapasite kontrolü
    final totalBits = payload.length * 8;
    final capacity = image.width * image.height * 3;
    if (totalBits > capacity) {
      throw Exception('Resim çok küçük, veri sığmıyor');
    }

    int bitIndex = 0;

    int getBit(int byte, int bit) => (byte >> (7 - bit)) & 1;

    // 5) Piksel piksel dolaş
    for (int y = 0; y < image.height; y++) {
      for (int x = 0; x < image.width; x++) {
        final p = image.getPixel(x, y);

        int r = p.r.toInt();
        int g = p.g.toInt();
        int b = p.b.toInt();

        // RGB kanallarına sırayla LSB yaz
        for (int c = 0; c < 3; c++) {
          if (bitIndex >= totalBits) break;

          final bytePos = bitIndex ~/ 8;
          final bitPos = bitIndex % 8;
          final bit = getBit(payload[bytePos], bitPos);

          if (c == 0) r = (r & 0xFE) | bit;
          if (c == 1) g = (g & 0xFE) | bit;
          if (c == 2) b = (b & 0xFE) | bit;

          bitIndex++;
        }

        image.setPixelRgb(x, y, r, g, b);
        if (bitIndex >= totalBits) break;
      }
      if (bitIndex >= totalBits) break;
    }

    // 6) PNG encode (JPEG kullanma!)
    return Uint8List.fromList(img.encodePng(image));
  }

  /// LSB steganografi ile resimden gizli metni çıkartır
  /// Sunucu tarafında kullanılmak üzere
  static String extractText(Uint8List imageBytes) {
    // 1) Resmi decode et
    final image = img.decodeImage(imageBytes);
    if (image == null) {
      throw Exception('Resim decode edilemedi');
    }

    // 2) İlk 4 byte'ı oku (length bilgisi)
    final lengthBytes = Uint8List(4);
    int bitIndex = 0;

    void setBit(int bytePos, int bitPos, int bit) {
      lengthBytes[bytePos] |= (bit << (7 - bitPos));
    }

    // İlk 32 bit = 4 byte length
    outerLoop:
    for (int y = 0; y < image.height; y++) {
      for (int x = 0; x < image.width; x++) {
        final p = image.getPixel(x, y);

        int r = p.r.toInt();
        int g = p.g.toInt();
        int b = p.b.toInt();

        // RGB kanallarından LSB oku
        for (int c = 0; c < 3; c++) {
          if (bitIndex >= 32) break outerLoop;

          final bytePos = bitIndex ~/ 8;
          final bitPos = bitIndex % 8;

          int bit;
          if (c == 0) {
            bit = r & 1;
          } else if (c == 1) {
            bit = g & 1;
          } else {
            bit = b & 1;
          }

          setBit(bytePos, bitPos, bit);
          bitIndex++;
        }
      }
    }

    // 3) Length'i parse et
    final length =
        (lengthBytes[0] << 24) |
        (lengthBytes[1] << 16) |
        (lengthBytes[2] << 8) |
        lengthBytes[3];

    if (length <= 0 || length > 1000000) {
      throw Exception('Geçersiz length: $length');
    }

    // 4) Secret bytes'ı oku
    final secretBytes = Uint8List(length);
    bitIndex = 0;

    void setSecretBit(int bytePos, int bitPos, int bit) {
      secretBytes[bytePos] |= (bit << (7 - bitPos));
    }

    // İlk 32 bit'i atla (length), sonraki length*8 bit'i oku
    int totalBitsToSkip = 32;
    int currentBit = 0;

    outerLoop2:
    for (int y = 0; y < image.height; y++) {
      for (int x = 0; x < image.width; x++) {
        final p = image.getPixel(x, y);

        int r = p.r.toInt();
        int g = p.g.toInt();
        int b = p.b.toInt();

        for (int c = 0; c < 3; c++) {
          // İlk 32 bit'i atla
          if (currentBit < totalBitsToSkip) {
            currentBit++;
            continue;
          }

          if (bitIndex >= length * 8) break outerLoop2;

          final bytePos = bitIndex ~/ 8;
          final bitPos = bitIndex % 8;

          int bit;
          if (c == 0) {
            bit = r & 1;
          } else if (c == 1) {
            bit = g & 1;
          } else {
            bit = b & 1;
          }

          setSecretBit(bytePos, bitPos, bit);
          bitIndex++;
        }
      }
    }

    // 5) UTF-8 string'e çevir
    return utf8.decode(secretBytes);
  }
}
