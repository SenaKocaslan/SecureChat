import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

class ApiService {

  static const bool kMockApi = true;

  static const String baseUrl = 'http://127.0.0.1:8000';

  static Future <bool> login(String username, String password) async{
    
    if (kMockApi) {
      await Future.delayed(const Duration(milliseconds: 300));
      return true; 
    }

    final uri = Uri.parse('$baseUrl/login');

    try {
      final response = await http.post(
        uri,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'username': username,
          'password': password,
        }),
      );
      if (response.statusCode == 200){
        return true;
      }else{
        print('Login error: ${response.statusCode} - ${response.body}');
        return false;
      }
    } catch (e) {
      rethrow;
    }
  }

  static Future<bool> registerUser(String username, File stegoImage) async {
    final uri = Uri.parse('$baseUrl/register');

    try {
      final request = http.MultipartRequest('POST', uri)
      ..fields['username'] = username
      ..files.add(
        await http.MultipartFile.fromPath('image', stegoImage.path),
      );

      final response = await request.send();

      if (response.statusCode == 200){
        return true;
      } else{
        print('Register error: ${response.statusCode}');
        return false;
      }
    } catch (e) {
      rethrow;
    }
  }

  static Future<List<String>> getUsers() async {
    final uri = Uri.parse('$baseUrl/users');

    try {
      final response = await http.get(uri);

      if(response.statusCode == 200) {
        final data = jsonDecode(response.body) as List<dynamic>;
        return data.map((e) => e.toString()).toList();
      } else{
        return[];
      }
    } catch (e) {
      rethrow;
    }
   
  }
}