import 'package:flutter/material.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  late final String username;
  late final String password; // şimdilik tutuluyor (DES key olacak)

  bool _initialized = false;

  final TextEditingController _messageController = TextEditingController();

  // Demo amaçlı: sabit kullanıcı listesi (sonra /users'tan çekeceğiz)
  final List<String> _users = ['ali', 'ayse', 'sena'];
  String? _selectedUser;

  // Basit mesaj modeli
  final List<_ChatMessage> _messages = [];

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    if (_initialized) return;

    final args =
        ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;

    username = (args?['username'] ?? 'unknown').toString();
    password = (args?['password'] ?? '').toString();

    _selectedUser ??= _users.isNotEmpty ? _users.first : null;

    _initialized = true;
  }

  void _sendMessage() {
    final text = _messageController.text.trim();
    if (text.isEmpty) return;
    if (_selectedUser == null) return;

    // Şimdilik şifresiz → sadece UI'ye ekliyoruz.
    // Sonra: cipher = CryptoService.encrypt(text, password) gönderilecek.
    setState(() {
      _messages.add(
        _ChatMessage(
          from: username,
          to: _selectedUser!,
          text: text,
          isMe: true,
          time: DateTime.now(),
        ),
      );
    });

    _messageController.clear();
  }

  @override
  void dispose() {
    _messageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDesktopWide = MediaQuery.of(context).size.width >= 900;

    return Scaffold(
      appBar: AppBar(
        title: Text('Secure Chat — $username'),
        centerTitle: true,
      ),
      body: isDesktopWide
          ? Row(
              children: [
                _buildUsersPanel(width: 260),
                const VerticalDivider(width: 1),
                Expanded(child: _buildChatPanel()),
              ],
            )
          : Column(
              children: [
                _buildUsersPanel(height: 140),
                const Divider(height: 1),
                Expanded(child: _buildChatPanel()),
              ],
            ),
    );
  }

  Widget _buildUsersPanel({double? width, double? height}) {
    return SizedBox(
      width: width,
      height: height,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Padding(
            padding: EdgeInsets.all(12),
            child: Text(
              'Kullanıcılar',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ),
          Expanded(
            child: ListView.separated(
              itemCount: _users.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, i) {
                final u = _users[i];
                final selected = u == _selectedUser;

                return ListTile(
                  title: Text(u),
                  selected: selected,
                  onTap: () {
                    setState(() => _selectedUser = u);
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChatPanel() {
    return Column(
      children: [
        // Üst başlık: kime yazıyoruz?
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          child: Text(
            _selectedUser == null
                ? 'Bir kullanıcı seç'
                : 'Sohbet: $_selectedUser',
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
        ),

        const Divider(height: 1),

        // Mesaj listesi
        Expanded(
          child: _messages.isEmpty
              ? const Center(
                  child: Text(
                    'Henüz mesaj yok',
                    style: TextStyle(color: Colors.grey),
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: _messages.length,
                  itemBuilder: (context, i) {
                    final m = _messages[i];
                    return _MessageBubble(message: m);
                  },
                ),
        ),

        const Divider(height: 1),

        // Mesaj yazma alanı
        Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _messageController,
                  onSubmitted: (_) => _sendMessage(),
                  decoration: const InputDecoration(
                    hintText: 'Mesaj yaz...',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              ElevatedButton(
                onPressed: _sendMessage,
                child: const Text('Gönder'),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// --------------------
// Basit mesaj modeli
// --------------------
class _ChatMessage {
  final String from;
  final String to;
  final String text;
  final bool isMe;
  final DateTime time;

  _ChatMessage({
    required this.from,
    required this.to,
    required this.text,
    required this.isMe,
    required this.time,
  });
}

// --------------------
// Mesaj balonu widget’ı
// --------------------
class _MessageBubble extends StatelessWidget {
  final _ChatMessage message;

  const _MessageBubble({required this.message});

  @override
  Widget build(BuildContext context) {
    final align =
        message.isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start;

    final bg = message.isMe ? Colors.blueGrey.shade700 : Colors.grey.shade800;

    return Column(
      crossAxisAlignment: align,
      children: [
        Container(
          margin: const EdgeInsets.symmetric(vertical: 6),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          constraints: const BoxConstraints(maxWidth: 520),
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Text(message.text),
        ),
      ],
    );
  }
}
